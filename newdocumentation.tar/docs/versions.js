
"use strict"

export const DOC_VERSIONS = [
	'stable',
	'v0.0',
	'dev'
];
