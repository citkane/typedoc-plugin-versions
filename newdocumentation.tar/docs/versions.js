
"use strict"

export const DOC_VERSIONS = [
	'stable',
	'v0.1',
	'v0.0',
	'dev'
];
